from Crypto.Cipher import DES, AES
from Crypto.Util.Padding import pad, unpad
import binascii

algo = input("Choose algorithm (DES/AES): ").upper()

if algo == "DES":
    cipher_module, key_len = DES, 8
elif algo == "AES":
    cipher_module, key_len = AES, 16
else:
    print("Invalid algorithm.")
    exit()

plaintext = input("Enter the plaintext: ")
key = input(f"Enter {key_len}-byte secret key: ")

if len(key) != key_len:
    print(f"Error: Key must be exactly {key_len} characters.")
    exit()

key = key.encode()
cipher = cipher_module.new(key, cipher_module.MODE_ECB)

# Encrypt
padded_text = pad(plaintext.encode(), cipher_module.block_size)
ciphertext = cipher.encrypt(padded_text)

# Decrypt
decrypted_text = unpad(cipher.decrypt(ciphertext),
                       cipher_module.block_size).decode()

print(f"\n----- {algo} Encryption & Decryption -----")
print("Plaintext           :", plaintext)
print("Secret Key          :", key.decode())
print("Ciphertext (Hex)    :", binascii.hexlify(ciphertext).decode())
print("Decrypted Plaintext :", decrypted_text)

if plaintext == decrypted_text:
    print("Verification        : SUCCESS")
else:
    print("Verification        : FAILED")