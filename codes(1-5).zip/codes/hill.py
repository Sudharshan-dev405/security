a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
text = input("Enter plaintext: ")

key = [[a, b], [c, d]]

det = (a * d - b * c) % 26
det_inv = None
for x in range(26):
    if (det * x) % 26 == 1:
        det_inv = x

if det_inv is None:
    print("Key not invertible mod 26")
    exit()

inv = [[(d * det_inv) % 26, (-b * det_inv) % 26],
       [(-c * det_inv) % 26, (a * det_inv) % 26]]

def transform(t, k):
    t = "".join(filter(str.isalpha, t.upper()))
    if len(t) % 2:
        t += "X"
    out = ""
    for i in range(0, len(t), 2):
        p1 = ord(t[i]) - ord('A')
        p2 = ord(t[i + 1]) - ord('A')
        c1 = (k[0][0] * p1 + k[0][1] * p2) % 26
        c2 = (k[1][0] * p1 + k[1][1] * p2) % 26
        out += chr(c1 + ord('A')) + chr(c2 + ord('A'))
    return out

ct = transform(text, key)
print("Ciphertext:", ct)
print("Decrypted:", transform(ct, inv))