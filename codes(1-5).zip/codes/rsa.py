from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import binascii

# Generate 2048-bit key pair
key = RSA.generate(2048)
public_key = key.publickey()
private_key = key

plaintext = input("Enter the plaintext: ")

# Encrypt with public key
cipher_encrypt = PKCS1_OAEP.new(public_key)
ciphertext = cipher_encrypt.encrypt(plaintext.encode())

# Decrypt with private key
cipher_decrypt = PKCS1_OAEP.new(private_key)
decrypted_text = cipher_decrypt.decrypt(ciphertext).decode()

print("\n----- RSA Encryption & Decryption -----")
print("Public Key :\n", public_key.export_key().decode())
print("\nPlaintext           :", plaintext)
print("Ciphertext (Hex)    :", binascii.hexlify(ciphertext).decode())
print("Decrypted Plaintext :", decrypted_text)

if plaintext == decrypted_text:
    print("Verification        : SUCCESS")
else:
    print("Verification        : FAILED")