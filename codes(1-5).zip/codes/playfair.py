key = input("Enter keyword: ").upper().replace("J", "I")
text = input("Enter plaintext: ").upper().replace("J", "I")

# Key matrix
letters = []
for ch in key + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
    if ch.isalpha() and ch not in letters:
        letters.append(ch)

m = [letters[i * 5 : i * 5 + 5] for i in range(5)]
for row in m:
    print(" ".join(row))

# Digraphs
text = "".join(c for c in text if c.isalpha())
pt, i = "", 0
while i < len(text):
    if i + 1 < len(text) and text[i] != text[i + 1]:
        pt += text[i] + text[i + 1]
        i += 2
    else:
        pt += text[i] + "X"
        i += 1
print("Processed:", pt)

def pos(ch):
    for i in range(5):
        for j in range(5):
            if m[i][j] == ch:
                return i, j

def process(t, s):
    out = ""
    for i in range(0, len(t), 2):
        r1, c1 = pos(t[i])
        r2, c2 = pos(t[i + 1])
        if r1 == r2:
            out += m[r1][(c1 + s) % 5] + m[r2][(c2 + s) % 5]
        elif c1 == c2:
            out += m[(r1 + s) % 5][c1] + m[(r2 + s) % 5][c2]
        else:
            out += m[r1][c2] + m[r2][c1]
    return out

ct = process(pt, 1)
print("Ciphertext:", ct)
print("Decrypted:", process(ct, -1))