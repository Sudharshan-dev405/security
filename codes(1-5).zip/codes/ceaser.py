text = input("Enter text: ")
key = int(input("Enter key: "))

def caesar(t, k):
    r = ""
    for ch in t:
        if ch.islower():
            r += chr((ord(ch) - ord('a') + k) % 26 + ord('a'))
        elif ch.isupper():
            r += chr((ord(ch) - ord('A') + k) % 26 + ord('A'))
        else:
            r += ch
    return r

enc = caesar(text, key)
print("Encrypted:", enc)
print("Decrypted:", caesar(enc, -key))

# Brute force
for k in range(26):
    print("Key", k, ":", caesar(enc, -k))