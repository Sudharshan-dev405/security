import math

text = input("Enter plaintext: ").upper().replace(" ", "")
cols = int(input("Enter columns: "))

rows = math.ceil(len(text) / cols)
text += "X" * (rows * cols - len(text))

# ---------- ROW MAJOR : fill column-wise, read row-wise ----------
m = [[''] * cols for _ in range(rows)]
k = 0
for c in range(cols):
    for r in range(rows):
        m[r][c] = text[k]
        k += 1

print("\nEncryption Matrix:")
for row in m:
    print(" ".join(row))

rc = ""
for r in range(rows):
    for c in range(cols):
        rc += m[r][c]
print("Row Major Cipher:", rc)

# Decrypt : fill row-wise, read column-wise
m2 = [[''] * cols for _ in range(rows)]
k = 0
for r in range(rows):
    for c in range(cols):
        m2[r][c] = rc[k]
        k += 1

plain = ""
for c in range(cols):
    for r in range(rows):
        plain += m2[r][c]
print("Recovered:", plain)

# ---------- COLUMN MAJOR : fill row-wise, read column-wise ----------
m = [[''] * cols for _ in range(rows)]
k = 0
for r in range(rows):
    for c in range(cols):
        m[r][c] = text[k]
        k += 1

print("\nEncryption Matrix:")
for row in m:
    print(" ".join(row))

cc = ""
for c in range(cols):
    for r in range(rows):
        cc += m[r][c]
print("Column Major Cipher:", cc)

# Decrypt : fill column-wise, read row-wise
m2 = [[''] * cols for _ in range(rows)]
k = 0
for c in range(cols):
    for r in range(rows):
        m2[r][c] = cc[k]
        k += 1

plain = ""
for r in range(rows):
    for c in range(cols):
        plain += m2[r][c]
print("Recovered:", plain)